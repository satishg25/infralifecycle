# Diff From Prod
## 03 - t in server name prefix
## 04 - hardcoded clustername and dcname
## 05 - hardcoded primaryvlanname and primaryvlanid
## 06 - line 296 datastorename: "CHZ1-WIN-TEST-PURE-01"
## 09 - vmfolder condition comment
## 16 - derived_target_ou
## 18 - Valuemation provider in vars file

# Convert master code to acc
```Powershell
$accRolePath = "C:\Users\B051867\OneDrive - Baloise\Hardik\Code\lib-shared-roles_test\roles"


$change3File = "$accRolePath\03_server_name_selection\templates\3_server_name_select.j2"
$lines = Get-Content -LiteralPath $change3File
$foundMatch = $false
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i].Contains('sv')) {
        $lines[$i] = [regex]::Replace($lines[$i], 'sv', 'tsv', 1)
        Set-Content -LiteralPath $change3File -Value $lines
        $foundMatch = $true
        break
    }
}
if (-not $foundMatch) {
    throw "No line containing 'sv' was found in '$change3File'."
}



$change4File = "$accRolePath\04_cluster_dc_ar_storage_selection\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change4File)
$pattern = @'
(?ms)^    - name: Set cluster and datacenter facts\r?\n      ansible\.builtin\.set_fact:\r?\n        clustername: "\{\{ selected_rows\[0\]\.clustername \}\}"\r?\n        dcname: "\{\{ selected_rows\[0\]\.dcname \}\}"\r?\n\r?\n    - name: Debug\r?\n      ansible\.builtin\.debug:\r?\n        msg:\r?\n          clustername: "\{\{ clustername \}\}"\r?\n          dcname: "\{\{ dcname \}\}"
'@
$matches = [regex]::Matches($content, $pattern)
if ($matches.Count -ne 1) {
    throw "Expected exactly one matching block in '$change4File'; found $($matches.Count)."
}
$replacement = @'
    - name: Set cluster and datacenter facts
      ansible.builtin.set_fact:
        actualclustername: "{{ selected_rows[0].clustername }}"
        actualdcname: "{{ selected_rows[0].dcname }}"
        clustername: "TEST"
        dcname: "dc2-chz2"

    - name: Debug
      ansible.builtin.debug:
        msg:
          actualclustername: "{{ actualclustername }}"
          actualdcname: "{{ actualdcname }}"
          clustername: "{{ clustername }}"
          dcname: "{{ dcname }}"
'@
$updatedContent = [regex]::Replace($content, $pattern, $replacement, 1)
[System.IO.File]::WriteAllText(
    $change4File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change5File = "$accRolePath\05_network_selection\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change5File)
$newline = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$normalizedContent = $content -replace "`r`n?", "`n"
$oldBlock = @'
    - name: Set facts
      ansible.builtin.set_fact:
          securityzonename: "{{ final_network_values.securityzonename }}"
          primaryvlanname: "{{ final_network_values.primaryvlanname }}"
          primaryvlanid: "{{ final_network_values.primaryvlanid }}"
          backupvlanname: "{{ final_network_values.backupvlanname }}"
          backupvlanid: "{{ final_network_values.backupvlanid }}"
          isactive: "{{ final_network_values.isactive }}"
          blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
          backupserverip: "{{ final_network_values.backupserverip }}"
          backupservername: "{{ final_network_values.backupservername }}"
      when: final_network_values is defined

    - name: debug
      ansible.builtin.debug:
          msg:
            ostype: "{{ ostype }}"
            addontype: "{{ addontype }}"
            dcname: "{{ dcname }}"
            servertype: "{{ servertype }}"
            environmenttype: "{{ environmenttype }}"
            securityzonename: "{{ final_network_values.securityzonename }}"
            primaryvlanname: "{{ primaryvlanname }}"
            primaryvlanid: "{{ primaryvlanid }}"
            backupvlanname: "{{ final_network_values.backupvlanname }}"
            backupvlanid: "{{ final_network_values.backupvlanid }}"
            isactive: "{{ final_network_values.isactive }}"
            blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
            backupserverip: "{{ final_network_values.backupserverip }}"
            backupservername: "{{ final_network_values.backupservername }}"
'@
$newBlock = @'
    - name: Set facts
      ansible.builtin.set_fact:
          securityzonename: "{{ final_network_values.securityzonename }}"
          actualprimaryvlanname: "{{ final_network_values.primaryvlanname }}"
          actualprimaryvlanid: "{{ final_network_values.primaryvlanid }}"
          primaryvlanname: "vlan_3013"
          primaryvlanid: "3013"
          backupvlanname: "{{ final_network_values.backupvlanname }}"
          backupvlanid: "{{ final_network_values.backupvlanid }}"
          isactive: "{{ final_network_values.isactive }}"
          blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
          backupserverip: "{{ final_network_values.backupserverip }}"
          backupservername: "{{ final_network_values.backupservername }}"
      when: final_network_values is defined

    - name: debug
      ansible.builtin.debug:
          msg:
            ostype: "{{ ostype }}"
            addontype: "{{ addontype }}"
            dcname: "{{ dcname }}"
            servertype: "{{ servertype }}"
            environmenttype: "{{ environmenttype }}"
            securityzonename: "{{ final_network_values.securityzonename }}"
            actualprimaryvlanname: "{{ actualprimaryvlanname }}"
            actualprimaryvlanid: "{{ actualprimaryvlanid }}"
            primaryvlanname: "{{ primaryvlanname }}"
            primaryvlanid: "{{ primaryvlanid }}"
            backupvlanname: "{{ final_network_values.backupvlanname }}"
            backupvlanid: "{{ final_network_values.backupvlanid }}"
            isactive: "{{ final_network_values.isactive }}"
            blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
            backupserverip: "{{ final_network_values.backupserverip }}"
            backupservername: "{{ final_network_values.backupservername }}"
'@
$oldBlock = $oldBlock -replace "`r`n?", "`n"
$newBlock = $newBlock -replace "`r`n?", "`n"
$matchCount = [regex]::Matches(
    $normalizedContent,
    [regex]::Escape($oldBlock)
).Count
if ($matchCount -ne 1) {
    throw "Expected exactly one matching block in '$change5File'; found $matchCount."
}
$updatedContent = $normalizedContent.Replace($oldBlock, $newBlock).Replace("`n", $newline)
[System.IO.File]::WriteAllText(
    $change5File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change6File = "$accRolePath\06_datastore_selection\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change6File)
$newline = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$normalizedContent = $content -replace "`r`n?", "`n"
$oldSetFact = @'
    - name: Set final datastorename and datastore capacity status
      ansible.builtin.set_fact:
        datastorename: "{{ (selected_datastore.name | default('')) | default() }}"
'@
$newSetFact = @'
    - name: Set final datastorename and datastore capacity status
      ansible.builtin.set_fact:
        actualdatastorename: "{{ (selected_datastore.name | default('')) | default() }}"
        datastorename: "CHZ1-WIN-TEST-PURE-01"
'@
$oldDebug = @'
    - name: Debug selected datastore values
      ansible.builtin.debug:
        msg:
          datastorename: "{{ datastorename }}"
          is_datastore_ok: "{{ is_datastore_ok }}"
'@
$newDebug = @'
    - name: Debug selected datastore values
      ansible.builtin.debug:
        msg:
          actualdatastorename: "{{ actualdatastorename }}"
          datastorename: "{{ datastorename }}"
          is_datastore_ok: "{{ is_datastore_ok }}"
'@
$oldSetFact = $oldSetFact -replace "`r`n?", "`n"
$newSetFact = $newSetFact -replace "`r`n?", "`n"
$oldDebug = $oldDebug -replace "`r`n?", "`n"
$newDebug = $newDebug -replace "`r`n?", "`n"
$setFactMatches = [regex]::Matches($normalizedContent, [regex]::Escape($oldSetFact)).Count
$debugMatches = [regex]::Matches($normalizedContent, [regex]::Escape($oldDebug)).Count
if ($setFactMatches -ne 1 -or $debugMatches -ne 1) {
    throw "Expected one match for each datastore block in '$change6File'; found set-fact: $setFactMatches, debug: $debugMatches."
}
$updatedContent = $normalizedContent.Replace($oldSetFact, $newSetFact).Replace($oldDebug, $newDebug).Replace("`n", $newline)
[System.IO.File]::WriteAllText(
    $change6File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change9File = "$accRolePath\09_vmware_create_vm_folder\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change9File)
$newline = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$normalizedContent = $content -replace "`r`n?", "`n"
$oldBlock = @'
    - name: Ensure VM folder hierarchy exists in vCenter 1
      vmware.vmware.folder:
        hostname: "{{ lookup('env', 'VMWARE_HOST_1') }}"
        username: "{{ lookup('env', 'VMWARE_USER_1') }}"
        password: "{{ lookup('env', 'VMWARE_PASSWORD_1') }}"
        validate_certs: "{{ (lookup('env', 'VMWARE_VALIDATE_CERTS_1') | default('false')) | bool }}"
        absolute_path: "{{ item }}"
        state: present
      loop: "{{ folder_levels1 }}"
      #when: dcname in ['dc1-chz1', 'dc1', 'chz1']
'@
$newBlock = @'
    - name: Ensure VM folder hierarchy exists in vCenter 1
      vmware.vmware.folder:
        hostname: "{{ lookup('env', 'VMWARE_HOST_1') }}"
        username: "{{ lookup('env', 'VMWARE_USER_1') }}"
        password: "{{ lookup('env', 'VMWARE_PASSWORD_1') }}"
        validate_certs: "{{ (lookup('env', 'VMWARE_VALIDATE_CERTS_1') | default('false')) | bool }}"
        absolute_path: "{{ item }}"
        state: present
      loop: "{{ folder_levels1 }}"
      when: dcname in ['dc1-chz1', 'dc1', 'chz1']
'@
$oldBlock = $oldBlock.TrimEnd([char[]]"`r`n")
$newBlock = $newBlock.TrimEnd([char[]]"`r`n")
$matchCount = [regex]::Matches(
    $normalizedContent,
    [regex]::Escape($oldBlock)
).Count
if ($matchCount -ne 1) {
    throw "Expected exactly one matching block in '$change9File'; found $matchCount."
}
$updatedContent = $normalizedContent.Replace($oldBlock, $newBlock).Replace("`n", $newline)
[System.IO.File]::WriteAllText(
    $change9File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)


$change18File = "$accRolePath\18_valuemation\vars\main.yml"
$content = [System.IO.File]::ReadAllText($change18File)
$pattern = '(?m)^provider: "BP-0000005"(?=\r?$)'
$matchCount = [regex]::Matches($content, $pattern).Count

if ($matchCount -ne 1) {
    throw "Expected exactly one matching provider line in '$change18File'; found $matchCount."
}
$updatedContent = [regex]::Replace($content, $pattern, 'provider: "BP-0000001"', 1)
[System.IO.File]::WriteAllText(
    $change18File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change96File = "$accRolePath\96_bau_send_failure_email\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change96File)
$pattern = '(?m)^    subject: "'
$matchCount = [regex]::Matches($content, $pattern).Count
if ($matchCount -ne 1) {
    throw "Expected exactly one subject line in '$change96File'; found $matchCount."
}
$updatedContent = [regex]::Replace($content, $pattern, '    subject: "Testing - ', 1)
[System.IO.File]::WriteAllText(
    $change96File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change97File = "$accRolePath\97_email_success\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change97File)
$pattern = '(?m)^    subject: "'
$matchCount = [regex]::Matches($content, $pattern).Count
if ($matchCount -ne 1) {
    throw "Expected exactly one subject line in '$change97File'; found $matchCount."
}
$updatedContent = [regex]::Replace($content, $pattern, '    subject: "Testing - ', 1)
[System.IO.File]::WriteAllText(
    $change97File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change98File = "$accRolePath\98_email_req_received\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change98File)
$pattern = '(?m)^        subject: "'
$matchCount = [regex]::Matches($content, $pattern).Count

if ($matchCount -ne 1) {
    throw "Expected exactly one subject line in '$change98File'; found $matchCount."
}
$updatedContent = [regex]::Replace($content, $pattern, '        subject: "Testing - ', 1)
[System.IO.File]::WriteAllText(
    $change98File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)



$change99File = "$accRolePath\99_send_failure_email\tasks\main.yml"
$content = [System.IO.File]::ReadAllText($change99File)
$pattern = '(?m)^    subject: "'
$matchCount = [regex]::Matches($content, $pattern).Count
if ($matchCount -ne 1) {
    throw "Expected exactly one subject line in '$change99File'; found $matchCount."
}
$updatedContent = [regex]::Replace($content, $pattern, '    subject: "Testing - ', 1)
[System.IO.File]::WriteAllText(
    $change99File,
    $updatedContent,
    [System.Text.UTF8Encoding]::new($false)
)
```

# Convert acc code to master
```Powershell
$restoreRoleRoot = "C:\Users\B051867\OneDrive - Baloise\Hardik\Code\lib-shared-roles_test\roles"

function Restore-ExactBlock {
    param(
        [string]$FilePath,
        [string]$ModifiedBlock,
        [string]$OriginalBlock
    )

    $fileText = [System.IO.File]::ReadAllText($FilePath)
    $fileNewline = if ($fileText.Contains("`r`n")) { "`r`n" } else { "`n" }
    $normalizedFileText = $fileText -replace "`r`n?", "`n"
    $normalizedModifiedBlock = $ModifiedBlock -replace "`r`n?", "`n"
    $normalizedOriginalBlock = $OriginalBlock -replace "`r`n?", "`n"
    $blockCount = [regex]::Matches(
        $normalizedFileText,
        [regex]::Escape($normalizedModifiedBlock)
    ).Count

    if ($blockCount -ne 1) {
        throw "Expected exactly one modified block in '$FilePath'; found $blockCount."
    }

    $restoredText = $normalizedFileText.Replace(
        $normalizedModifiedBlock,
        $normalizedOriginalBlock
    ).Replace("`n", $fileNewline)

    [System.IO.File]::WriteAllText(
        $FilePath,
        $restoredText,
        [System.Text.UTF8Encoding]::new($false)
    )
}

$restore03File = "$restoreRoleRoot\03_server_name_selection\templates\3_server_name_select.j2"
$restore03Text = [System.IO.File]::ReadAllText($restore03File)
$restore03Line = [regex]::Match($restore03Text, '(?m)^.*tsv.*$')
if (-not $restore03Line.Success) {
    throw "No line containing 'tsv' was found in '$restore03File'."
}
$restore03LineText = $restore03Line.Value
$restore03Position = $restore03LineText.IndexOf('tsv', [System.StringComparison]::Ordinal)
$restore03OriginalLine = $restore03LineText.Substring(0, $restore03Position) +
    'sv' +
    $restore03LineText.Substring($restore03Position + 3)
$restore03Text = $restore03Text.Substring(0, $restore03Line.Index) +
    $restore03OriginalLine +
    $restore03Text.Substring($restore03Line.Index + $restore03Line.Length)
[System.IO.File]::WriteAllText(
    $restore03File,
    $restore03Text,
    [System.Text.UTF8Encoding]::new($false)
)

$restore04File = "$restoreRoleRoot\04_cluster_dc_ar_storage_selection\tasks\main.yml"
$restore04Modified = @'
    - name: Set cluster and datacenter facts
      ansible.builtin.set_fact:
        actualclustername: "{{ selected_rows[0].clustername }}"
        actualdcname: "{{ selected_rows[0].dcname }}"
        clustername: "TEST"
        dcname: "dc2-chz2"

    - name: Debug
      ansible.builtin.debug:
        msg:
          actualclustername: "{{ actualclustername }}"
          actualdcname: "{{ actualdcname }}"
          clustername: "{{ clustername }}"
          dcname: "{{ dcname }}"
'@
$restore04Original = @'
    - name: Set cluster and datacenter facts
      ansible.builtin.set_fact:
        clustername: "{{ selected_rows[0].clustername }}"
        dcname: "{{ selected_rows[0].dcname }}"

    - name: Debug
      ansible.builtin.debug:
        msg:
          clustername: "{{ clustername }}"
          dcname: "{{ dcname }}"
'@
Restore-ExactBlock $restore04File $restore04Modified $restore04Original

$restore05File = "$restoreRoleRoot\05_network_selection\tasks\main.yml"
$restore05Modified = @'
    - name: Set facts
      ansible.builtin.set_fact:
          securityzonename: "{{ final_network_values.securityzonename }}"
          actualprimaryvlanname: "{{ final_network_values.primaryvlanname }}"
          actualprimaryvlanid: "{{ final_network_values.primaryvlanid }}"
          primaryvlanname: "vlan_3013"
          primaryvlanid: "3013"
          backupvlanname: "{{ final_network_values.backupvlanname }}"
          backupvlanid: "{{ final_network_values.backupvlanid }}"
          isactive: "{{ final_network_values.isactive }}"
          blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
          backupserverip: "{{ final_network_values.backupserverip }}"
          backupservername: "{{ final_network_values.backupservername }}"
      when: final_network_values is defined

    - name: debug
      ansible.builtin.debug:
          msg:
            ostype: "{{ ostype }}"
            addontype: "{{ addontype }}"
            dcname: "{{ dcname }}"
            servertype: "{{ servertype }}"
            environmenttype: "{{ environmenttype }}"
            securityzonename: "{{ final_network_values.securityzonename }}"
            actualprimaryvlanname: "{{ actualprimaryvlanname }}"
            actualprimaryvlanid: "{{ actualprimaryvlanid }}"
            primaryvlanname: "{{ primaryvlanname }}"
            primaryvlanid: "{{ primaryvlanid }}"
            backupvlanname: "{{ final_network_values.backupvlanname }}"
            backupvlanid: "{{ final_network_values.backupvlanid }}"
            isactive: "{{ final_network_values.isactive }}"
            blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
            backupserverip: "{{ final_network_values.backupserverip }}"
            backupservername: "{{ final_network_values.backupservername }}"
'@
$restore05Original = @'
    - name: Set facts
      ansible.builtin.set_fact:
          securityzonename: "{{ final_network_values.securityzonename }}"
          primaryvlanname: "{{ final_network_values.primaryvlanname }}"
          primaryvlanid: "{{ final_network_values.primaryvlanid }}"
          backupvlanname: "{{ final_network_values.backupvlanname }}"
          backupvlanid: "{{ final_network_values.backupvlanid }}"
          isactive: "{{ final_network_values.isactive }}"
          blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
          backupserverip: "{{ final_network_values.backupserverip }}"
          backupservername: "{{ final_network_values.backupservername }}"
      when: final_network_values is defined

    - name: debug
      ansible.builtin.debug:
          msg:
            ostype: "{{ ostype }}"
            addontype: "{{ addontype }}"
            dcname: "{{ dcname }}"
            servertype: "{{ servertype }}"
            environmenttype: "{{ environmenttype }}"
            securityzonename: "{{ final_network_values.securityzonename }}"
            primaryvlanname: "{{ primaryvlanname }}"
            primaryvlanid: "{{ primaryvlanid }}"
            backupvlanname: "{{ final_network_values.backupvlanname }}"
            backupvlanid: "{{ final_network_values.backupvlanid }}"
            isactive: "{{ final_network_values.isactive }}"
            blucatbackupvlanid: "{{ final_network_values.blucatbackupvlanid }}"
            backupserverip: "{{ final_network_values.backupserverip }}"
            backupservername: "{{ final_network_values.backupservername }}"
'@
Restore-ExactBlock $restore05File $restore05Modified $restore05Original

$restore06File = "$restoreRoleRoot\06_datastore_selection\tasks\main.yml"
$restore06Modified = @'
    - name: Set final datastorename and datastore capacity status
      ansible.builtin.set_fact:
        actualdatastorename: "{{ (selected_datastore.name | default('')) | default() }}"
        datastorename: "CHZ1-WIN-TEST-PURE-01"
'@
$restore06Original = @'
    - name: Set final datastorename and datastore capacity status
      ansible.builtin.set_fact:
        datastorename: "{{ (selected_datastore.name | default('')) | default() }}"
'@
Restore-ExactBlock $restore06File $restore06Modified $restore06Original

$restore06DebugModified = @'
    - name: Debug selected datastore values
      ansible.builtin.debug:
        msg:
          actualdatastorename: "{{ actualdatastorename }}"
          datastorename: "{{ datastorename }}"
          is_datastore_ok: "{{ is_datastore_ok }}"
'@
$restore06DebugOriginal = @'
    - name: Debug selected datastore values
      ansible.builtin.debug:
        msg:
          datastorename: "{{ datastorename }}"
          is_datastore_ok: "{{ is_datastore_ok }}"
'@
Restore-ExactBlock $restore06File $restore06DebugModified $restore06DebugOriginal

$restore09File = "$restoreRoleRoot\09_vmware_create_vm_folder\tasks\main.yml"
$restore09Modified = @'
    - name: Ensure VM folder hierarchy exists in vCenter 1
      vmware.vmware.folder:
        hostname: "{{ lookup('env', 'VMWARE_HOST_1') }}"
        username: "{{ lookup('env', 'VMWARE_USER_1') }}"
        password: "{{ lookup('env', 'VMWARE_PASSWORD_1') }}"
        validate_certs: "{{ (lookup('env', 'VMWARE_VALIDATE_CERTS_1') | default('false')) | bool }}"
        absolute_path: "{{ item }}"
        state: present
      loop: "{{ folder_levels1 }}"
      when: dcname in ['dc1-chz1', 'dc1', 'chz1']
'@
$restore09Original = @'
    - name: Ensure VM folder hierarchy exists in vCenter 1
      vmware.vmware.folder:
        hostname: "{{ lookup('env', 'VMWARE_HOST_1') }}"
        username: "{{ lookup('env', 'VMWARE_USER_1') }}"
        password: "{{ lookup('env', 'VMWARE_PASSWORD_1') }}"
        validate_certs: "{{ (lookup('env', 'VMWARE_VALIDATE_CERTS_1') | default('false')) | bool }}"
        absolute_path: "{{ item }}"
        state: present
      loop: "{{ folder_levels1 }}"
      #when: dcname in ['dc1-chz1', 'dc1', 'chz1']
'@
Restore-ExactBlock $restore09File $restore09Modified $restore09Original

$restore18File = "$restoreRoleRoot\18_valuemation\vars\main.yml"
$restore18Text = [System.IO.File]::ReadAllText($restore18File)
$restore18Pattern = '(?m)^provider: "BP-0000001"(?=\r?$)'
$restore18Count = [regex]::Matches($restore18Text, $restore18Pattern).Count
if ($restore18Count -ne 1) {
    throw "Expected exactly one modified provider line in '$restore18File'; found $restore18Count."
}
$restore18Text = [regex]::Replace($restore18Text, $restore18Pattern, 'provider: "BP-0000005"', 1)
[System.IO.File]::WriteAllText(
    $restore18File,
    $restore18Text,
    [System.Text.UTF8Encoding]::new($false)
)

$restore96File = "$restoreRoleRoot\96_bau_send_failure_email\tasks\main.yml"
$restore96Text = [System.IO.File]::ReadAllText($restore96File)
$restore96Pattern = '(?m)^    subject: "Testing - '
$restore96Count = [regex]::Matches($restore96Text, $restore96Pattern).Count
if ($restore96Count -ne 1) {
    throw "Expected exactly one modified subject line in '$restore96File'; found $restore96Count."
}
$restore96Text = [regex]::Replace($restore96Text, $restore96Pattern, '    subject: "', 1)
[System.IO.File]::WriteAllText(
    $restore96File,
    $restore96Text,
    [System.Text.UTF8Encoding]::new($false)
)

$restore97File = "$restoreRoleRoot\97_email_success\tasks\main.yml"
$restore97Text = [System.IO.File]::ReadAllText($restore97File)
$restore97Pattern = '(?m)^    subject: "Testing - '
$restore97Count = [regex]::Matches($restore97Text, $restore97Pattern).Count
if ($restore97Count -ne 1) {
    throw "Expected exactly one modified subject line in '$restore97File'; found $restore97Count."
}
$restore97Text = [regex]::Replace($restore97Text, $restore97Pattern, '    subject: "', 1)
[System.IO.File]::WriteAllText(
    $restore97File,
    $restore97Text,
    [System.Text.UTF8Encoding]::new($false)
)

$restore98File = "$restoreRoleRoot\98_email_req_received\tasks\main.yml"
$restore98Text = [System.IO.File]::ReadAllText($restore98File)
$restore98Pattern = '(?m)^        subject: "Testing - '
$restore98Count = [regex]::Matches($restore98Text, $restore98Pattern).Count
if ($restore98Count -ne 1) {
    throw "Expected exactly one modified subject line in '$restore98File'; found $restore98Count."
}
$restore98Text = [regex]::Replace($restore98Text, $restore98Pattern, '        subject: "', 1)
[System.IO.File]::WriteAllText(
    $restore98File,
    $restore98Text,
    [System.Text.UTF8Encoding]::new($false)
)

$restore99File = "$restoreRoleRoot\99_send_failure_email\tasks\main.yml"
$restore99Text = [System.IO.File]::ReadAllText($restore99File)
$restore99Pattern = '(?m)^    subject: "Testing - '
$restore99Count = [regex]::Matches($restore99Text, $restore99Pattern).Count
if ($restore99Count -ne 1) {
    throw "Expected exactly one modified subject line in '$restore99File'; found $restore99Count."
}
$restore99Text = [regex]::Replace($restore99Text, $restore99Pattern, '    subject: "', 1)
[System.IO.File]::WriteAllText(
    $restore99File,
    $restore99Text,
    [System.Text.UTF8Encoding]::new($false)
)
```
