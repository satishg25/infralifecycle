[string]$DeploymentType = 'Install'
[string]$DeployMode = 'Silent'
[switch]$AllowRebootPassThru = $false
[switch]$TerminalServerMode = $false
[switch]$DisableLogging = $false

Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}

[string]$appVendor = 'Prometheus'
[string]$appName = 'Prometheus Agent (windows_exporter)'
[string]$appVersion = '0.30.4'
[string]$appArch = ''
[string]$appLang = 'EN'
[string]$appRevision = '01'
[string]$appScriptVersion = '1.0.0'
[string]$appScriptDate = '2026.09.20'
[string]$appScriptAuthor = 'Automation'
[string]$installName = ''
[string]$installTitle = ''

[int32]$mainExitCode = 0

[string]$deployAppScriptFriendlyName = 'Deploy Application'
[version]$deployAppScriptVersion = [version]'3.8.2'
[string]$deployAppScriptDate = '08/05/2020'
[hashtable]$deployAppScriptParameters = $psBoundParameters

[string]$installRoot = 'C:\Program Files\windows_exporter'
[string]$serviceName = 'windows_exporter'
[string]$metricsUrl = 'http://localhost:9100/metrics'

# Package is staged under C:\Temp by the Ansible role; resolve the version folder dynamically
[string]$packageRoot = Get-ChildItem -Path 'C:\Temp' -Directory -Filter '*Promet*' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
If (-not $packageRoot) { Write-Warning 'Prometheus package folder not found under C:\Temp.'; Exit 0 }

[string]$scriptDirectory = Get-ChildItem -Path $packageRoot -Directory -Recurse -Filter 'Update' -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
If (-not $scriptDirectory) { Write-Warning "Update folder not found under [$packageRoot]."; Exit 0 }

[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Write-Warning "Module does not exist at the specified location [$moduleAppDeployToolkitMain]."; Exit 0 }
If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }

Try {
    [string]$installPhase = 'Pre-Installation'
    Show-InstallationProgress

    Get-Service -Name $serviceName -ErrorAction 'SilentlyContinue' | Stop-Service -Force -ErrorAction 'SilentlyContinue'

    [string]$installPhase = 'Installation'
    $msiFile = Get-ChildItem -Path "$scriptDirectory\Files" -Filter 'windows_exporter-*.msi' -ErrorAction 'SilentlyContinue' | Select-Object -First 1
    If (-not $msiFile) { Throw "No windows_exporter MSI found in [$scriptDirectory\Files]." }
    Execute-MSI -Action 'Install' -Path $msiFile.FullName -Parameters '/qn /norestart'

    [string]$installPhase = 'Post-Installation'

    # Service must be stopped before the config file can be replaced
    Get-Service -Name $serviceName -ErrorAction 'SilentlyContinue' | Stop-Service -Force -ErrorAction 'SilentlyContinue'
    Start-Sleep -Seconds 5

    $sourceConfig = Join-Path $scriptDirectory 'SupportFiles\config.yml'
    If (-not (Test-Path -LiteralPath $sourceConfig)) { $sourceConfig = Join-Path $packageRoot 'config.yml' }
    If (-not (Test-Path -LiteralPath $sourceConfig)) { Throw 'config.yml not found in the staged package.' }
    Copy-File -Path $sourceConfig -Destination "$installRoot\config.yml"

    If (Test-Path -LiteralPath "$scriptDirectory\SupportFiles\windows_exporter.reg") {
        Write-Log -Message 'Importing windows_exporter registry settings.' -Source 'Post-Installation'
        Start-Process -FilePath 'reg.exe' -ArgumentList "import `"$scriptDirectory\SupportFiles\windows_exporter.reg`"" -Wait -NoNewWindow -ErrorAction 'SilentlyContinue'
    }

    # Point the service executable path at the replaced config file
    cmd.exe /c 'sc config windows_exporter binPath= "\"C:\Program Files\windows_exporter\windows_exporter.exe\" --config.file=\"C:\Program Files\windows_exporter\config.yml\""' | Out-Null
    cmd.exe /c 'sc config windows_exporter start= delayed-auto' | Out-Null

    Restart-Service -Name $serviceName -Force -ErrorAction 'Stop'

    [string]$installPhase = 'Post-Installation Validation'
    $imagePath = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName" -Name 'ImagePath' -ErrorAction 'SilentlyContinue').ImagePath
    Write-Log -Message "Service ImagePath: $imagePath" -Source 'Validation'
    If ($imagePath -notlike '*config.file=*config.yml*') { Throw 'Service executable path does not reference config.yml.' }

    $service = Get-Service -Name $serviceName -ErrorAction 'SilentlyContinue'
    If (-not $service -or $service.Status -ne 'Running') { Throw 'windows_exporter service is not running.' }

    $metricsOk = $false
    For ($i = 1; $i -le 6; $i++) {
        Try {
            $response = Invoke-WebRequest -Uri $metricsUrl -UseBasicParsing -TimeoutSec 20
            If ($response.StatusCode -eq 200 -and $response.Content.Length -gt 0) { $metricsOk = $true; Break }
        } Catch {
            Write-Log -Message "Metrics endpoint not ready (attempt $i): $($_.Exception.Message)" -Source 'Validation'
        }
        Start-Sleep -Seconds 10
    }
    If (-not $metricsOk) { Throw "Metrics endpoint [$metricsUrl] did not return content." }

    Write-Log -Message 'Prometheus agent installation validated successfully.' -Source 'Validation'
    $mainExitCode = 1
} Catch {
    # Any unhandled error must resolve to 0 so it can never be mistaken for the success code (1)
    Write-Log -Message "Installation failed with error: $($_.Exception.Message)" -Source 'Installation'
    $mainExitCode = 0
}
Exit-Script -ExitCode $mainExitCode
