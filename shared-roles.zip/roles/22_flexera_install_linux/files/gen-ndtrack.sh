#!/bin/bash
# Author: DOIT-Flexera Baloise Team ( Fred/Aldo )
#
# Date: 24 Feb 2026
# Description:
#     This script generates an updated version of Flexera ndtrack.sh ( adding "-Baloise-OMO" to the version number )
#     resolving the issue when the /tmp filesystem is mounted with noexec option.
#     Instead of using /tmp, the script leverages /var/tmp to ensure the agent (ndtrack) can execute properly.
#
# What the script does
#  1. backup ndtrack.sh to ndtrack.sh.bck
#  2. Extract the non-compressed script part from ndtrack.sh
#  3. Modify the version number string by adding "-Baloise-OMO"
#  4. Insert a /tmp safety condition to not use this location (/var/tmp is used instead if $HOME is empty )
#  5. Rebuild ndtrack.sh file by concatenating the non-compressed part and gzip payload
#
#
#   info : GZIP format is identified by the first occurrence bytes: 1F 8B 08 (gzip header signature)
#
# Usage:     - Generate the new ndtrack.sh version
#            ./gen-ndtrack.sh
#              ----------------------
#                current ndtrack 25.0.0.2273-Baloise-OMO
#                ndtrack.sh created successfully
#              ----------------------
#
#            - Check the version
#            ./ndtrack.sh --version
#              ----------------------
#                ndtrack 25.0.0.2273-Baloise-OMO
#              ----------------------
#
#            - Test extraction
#            ./ndtrack.sh --test
#              ----------------------
#                Testing ndtrack, version 25.0.0.2273-Baloise-OMO
#                 ===== Testing full archive...
#                     ...
#                SUCCESS: Archive is OK.
#                 ===== Testing current platform...
#                     ...
#                SUCCESS: Platform dependent package is OK.
#              ----------------------
#
#     HCL uses Ansible deployment where the agent files are delivered to /root/flexera
#     A root cronjob triggers the ndtrack.sh at night with specifics arguments ( include/exclude ...)
#
#******************************************************************

printf "current %s %s\n" $(./ndtrack.sh --version)
mv ./ndtrack.sh ./ndtrack.sh.bck || echo "rename FAILED"

#  to identify gzip format
#  search the first three bytes of a GZIP file
offset=$(grep -obam1 $'\x1f\x8b\x08' ndtrack.sh.bck | awk -F: '{print $1}')

#  if GZIP format is found
if [[ "$offset" =~ ^[0-9]+$ ]]; then
   # extract script part
   head -c "$offset" ./ndtrack.sh.bck >  ./ndtrack.sh
   #---------------------
   # change version string
   version=$(awk '/--version/,/exit/ { match($0, /[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/, m)
                                       if (m[0] != "") print m[0]  }r'             ./ndtrack.sh )
   insert=' printf '"'"'%s'"'"' '"'""'"' '"'"'echo OK'"'"' > "$basetmppath/x_$$"; chmod 555 "$basetmppath/x_$$"; if "$basetmppath/x_$$" >/dev/null; then echo "$basetmppath Filesystem is executable"; else echo "$basetmppath Filesystem is NOT executable"; continue; fi'
   sed -i '/continue/! {/^[[:space:]]*oictmpdir=.*ndtrack\.\$RANDOM\.\$RANDOM\.\$\$/ s|$|; '"$insert"'|}' ./ndtrack.sh
   sed -i "/-Baloise-OMO/! s/${version}/${version}-Baloise-OMO/" ./ndtrack.sh

   # add condition, skip the /tmp (due to noexec mount)
   # substitution only if -Baloise-OMO is NOT present
   sed -i '/Baloise-OMO/! { /^[[:space:]]*oictmpdir=.*ndtrack\.\$RANDOM\.\$RANDOM\.\$\$/ s|$|; |}' ./ndtrack.sh

   # join together script part + gzip payload
   tail -c +$((offset + 1)) ndtrack.sh.bck >> ./ndtrack.sh
   #---------------------
else
   echo "No gzip file format found!";exit 1
fi
 chmod 755 ./ndtrack.sh
 printf "ndtrack.sh created successfully\n"
exit 0
