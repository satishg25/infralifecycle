[string]$DeploymentType = 'Install'
[string]$DeployMode = 'Silent'
[switch]$AllowRebootPassThru = $false
[switch]$TerminalServerMode = $false
[switch]$DisableLogging = $false

Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}
[string]$appVendor = 'NXLog Ltd'
[string]$appName = 'Nagios NXLog'
[string]$appVersion = '6.13.10718'
[string]$appArch = ''
[string]$appLang = 'EN'
[string]$appRevision = '01'
[string]$appScriptVersion = '1.0.0'
[string]$appScriptDate = '2026.06.01'
[string]$appScriptAuthor = 'Tomas Zukovskis'
[string]$installName = ''
[string]$installTitle = ''

[int32]$mainExitCode = 0

[string]$deployAppScriptFriendlyName = 'Deploy Application'
[version]$deployAppScriptVersion = [version]'3.8.2'
[string]$deployAppScriptDate = '08/05/2020'
[hashtable]$deployAppScriptParameters = $psBoundParameters

[string]$scriptDirectory = "C:\Temp\NXLog 6.13.10718"

[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Write-Warning "Module does not exist at the specified location [$moduleAppDeployToolkitMain]."; Exit 0 }
If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }

Try {
    If ($deploymentType -ine 'Uninstall' -and $deploymentType -ine 'Repair') {
        [string]$installPhase = 'Pre-Installation'

        Show-InstallationProgress
        # Stop the service first so its binaries aren't locked when the folder/MSI is removed/reinstalled
        Get-Service -DisplayName nxlog -ErrorAction SilentlyContinue | Stop-Service -Force -ErrorAction SilentlyContinue
        if (Test-Path -Path "C:\Program Files\nxlog") {
            Write-Log "Folder 'C:\Program Files\nxlog' exists, removing directory."
            Remove-Item -Path "C:\Program Files\nxlog" -Recurse -Force
        } else {
            Write-Log "Folder 'C:\Program Files\nxlog' does not exist, proceeding with regular installation steps."
        }

        [string]$installPhase = 'Installation'
        If ($useDefaultMsi) {
            [hashtable]$ExecuteDefaultMSISplat =  @{ Action = 'Install'; Path = $defaultMsiFile }; If ($defaultMstFile) { $ExecuteDefaultMSISplat.Add('Transform', $defaultMstFile) }
            Execute-MSI @ExecuteDefaultMSISplat; If ($defaultMspFiles) { $defaultMspFiles | ForEach-Object { Execute-MSI -Action 'Patch' -Path $_ } }
        }

        Execute-MSI -Action 'Install' -Path "nxlog-6.13.10718_windows_x64.msi" -Parameters '/qn /norestart'
        Copy-File -Path "$dirSupportFiles\ca.pem" -Destination "C:\Program Files\nxlog\cert"
        Copy-File -Path "$dirSupportFiles\nxlog.conf" -Destination "C:\Program Files\nxlog\conf"
        [string]$installPhase = 'Post-Installation'

        Get-Service -DisplayName nxlog | Restart-Service

        # Validate the service came up successfully before deciding the exit code
        [string]$installPhase = 'Post-Installation Validation'
        $nxlogService = Get-Service -DisplayName nxlog -ErrorAction 'SilentlyContinue'
        If ($nxlogService -and $nxlogService.Status -eq 'Running') {
            Write-Log "NXLog service is running. Installation validated successfully."
            $mainExitCode = 1
        } Else {
            Write-Log "NXLog service is not running. Installation validation failed."
            $mainExitCode = 0
        }
    }
} Catch {
    # Any unhandled error must resolve to 0 so it can never be mistaken for the success code (1)
    Write-Log "Installation failed with error: $($_.Exception.Message)"
    $mainExitCode = 0
}
Exit-Script -ExitCode $mainExitCode