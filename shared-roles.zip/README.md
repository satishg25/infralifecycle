# lib-shared-roles

## Overview
This repository is an Ansible Collection (`aap.shared`) containing shared roles used across CloudStudio automation projects.

## Repository scope
Hosts reusable Ansible roles consumed by other repositories via `requirements.yml` as a Git-sourced collection.

## Governance Alignment
This repository follows the governance model described for Bitbucket:
- Single source of truth in Git.
- Pull request based change control on the default branch.

## Ownership
- Repository owner: BAU Automation Team
- Technical owner: BAU Automation Team
- Support channel: Team mailbox / ticket queue
