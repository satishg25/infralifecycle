main.yml
│
├── PLAY 0  VALIDATE               (localhost)
│   ├── 100_debug_params, 31_rhel_ha_preflight (controller inputs), 98 mail
│   └── ha_inventory: virtual hosts ha-node1-build, ha-node2-build, ha-vip-build
│                                  ← one fact scope per node, no SSH
│
├── PLAY 1  NAME + ALLOCATE
│   ├── 1a name nodes              ← SERIAL: node 1 = role 03, node 2 = ha_name_derive
│   │                                (skipped when names are given)
│   ├── 1b cluster allocate        ← ONCE: 04, 05, 08, 09 on localhost, copy values to nodes
│   ├── 1c node allocate           ← SERIAL: 06 datastore, 06 host, 07 IP, 07_second
│   ├── 1d VIP                     ← provided, or role 07 on ha-vip-build (SERIAL)
│   ├── GATE                       ← any node failed? promote to failmsg
│   └── resolve ha_nodes (name, ip) + ha_vip_reserve (ha_vip_resolved, DNS check)
│
├── PLAY 2  PROVISION              ← per node, parallel
│   ├── 39_rhel_node_build: 10, 11, 12  (VMs stay powered OFF)
│   ├── GATE
│   └── 38_vmware_ha_infra         ← EnableUUID, DRS anti-affinity rule, shared multi-writer disk
│
├── PLAY 3  CONFIGURE              ← per node, parallel
│   ├── 39_rhel_node_build: power-on, 13 ... 24   (same baseline as standalone)
│   ├── GATE
│   ├── Cohesity 26                ← SERIAL, skip with ha_run_backup=false
│   ├── 27_opsramp_onboard
│   └── GATE + register real nodes (SSH, Machine credential)
│
├── PLAY 4  HA CORE                ← real nodes
│   ├── 31 preflight (node) + 35 shared storage (LVM)
│   ├── GATE node_ready
│   ├── 32 cluster → 36 fencing → 37 quorum → 33 resources (LVM, FS, VIP, app)
│   ├── 34 validation (build); opt-in: fence test + failover test
│   └── GATE ha_core
│
├── PLAY 5  CLOSE
│   ├── ha_cloudstudio_update      ← same guards as standalone 95
│   ├── 100_debug_params
│   ├── ha_email_success           ← failmsg == nomsg, with cluster block
│   └── 99 + 96 failure mails      ← failmsg != nomsg
│
└── ANY FAILURE: ha_stage block/rescue sets failmsg, failmail, sucmail
    → later stages skip → gate promotes node failures → mails → job red
    resume: rhel_ha_nodes[].state + <stage>_done flags from the failure mail
