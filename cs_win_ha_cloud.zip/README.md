# svc-cloudstudio

## Overview
This repository stores code for the automation of CloudStudio Infra provisioning Catalogues. 

## Repository scope
Hosts the playbooks, roles, inventories, variables for CloudStudio VM Provisioning.

## Governance Alignment
This repository follows the governance model described for Bitbucket:
- Single source of truth in Git.
- Pull request based change control on the default branch.

## Ownership
- Repository owner: BAU Automation Team
- Technical owner: BAU Automation Team
- Support channel: Team mailbox / ticket queue
