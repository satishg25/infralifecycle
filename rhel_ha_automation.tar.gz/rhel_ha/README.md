# RHEL 8 HA (Vanilla) - Ansible automation

Two-node Pacemaker/Corosync cluster, built by reusing the standalone RHEL roles (`aap.shared.*`) plus new HA roles,
orchestrated by `main.yml`. Backend: hand-rolled `pcs` (the RHEL system role is reserved, not built).

## Status: what has and has not been run

| Verified here (localhost, `tests/run_tests.sh`, 18 checks) | NOT verified (needs your lab) |
|---|---|
| `ansible-playbook --syntax-check`, `ansible-lint`, `yamllint` clean | Anything touching vCenter, ESXi, a real node or pcs |
| Stage runner: success, resume flag, failure -> `failmsg`/`failmail`/`sucmail`, skip-after-failure, HTML escaping | Per-node virtual build hosts with the real standalone roles (spike 1) |
| Gate: failed node promoted; node that never reached the phase marker caught | `crm_mon` XML attribute names, `pcs status nodes` output format on your RHEL minor |
| Controller preflight: example accepted, 13 bad inputs rejected | `fence_vmware_rest` option names (detected via `pcs stonith describe`, still check) |
| Patched role 97 renders the cluster block for two nodes | `vmware_guest_disk` multi-writer params on your community.vmware version |

## Layout

| Path | What |
|---|---|
| `main.yml` | Plays 0-5: validate, allocate, provision, configure, HA core, close. Tags per phase |
| `roles/ha_stage` | Stage runner (block/rescue -> framework failure convention), `gate.yml`, `close_facts.yml` |
| `roles/ha_inventory` | Virtual `<node>-build` hosts, per-node variable init, real node registration |
| `roles/39_rhel_node_build` | Wrapper: reuses standalone roles by phase (`cluster_allocate`, `node_allocate`, `node_provision`, `node_configure`) |
| `roles/ha_vip_reserve` | VIP + DNS check (`provided` mode; BlueCat reservation not implemented) |
| `roles/31..37` | preflight, cluster, resources, validation, shared storage, fencing, quorum |
| `roles/38_vmware_ha_infra` | DRS anti-affinity rule, shared multi-writer disk, vSphere HA reminder |
| `patches/95_*`, `patches/97_*` | Repackaged roles (+ `.diff` against the originals in `docs/`) |
| `vars/ha_example.yml` | Lab example, placeholders only |

`ha_role_ns` (in `vars/ha_common.yml`) is the namespace for the new roles (`""` = local `roles/`); switch to your
collection prefix once they move into `aap.shared`. `ha_standalone_ns` is `aap.shared.` for the existing roles.

## Run it

```bash
export ANSIBLE_CONFIG=$PWD/ansible.cfg
tests/run_tests.sh                                   # local checks first

# full run
ansible-playbook -i localhost, main.yml -e @vars/ha_example.yml

# one phase (init/gate/close plays always run; mail/CloudStudio off while testing)
ansible-playbook -i localhost, main.yml -e @vars/ha_example.yml \
  -e ha_skip_mail=true -e ha_skip_cloudstudio=true --tags allocate
```

Skipped phases only work if their results are supplied as extra_vars (same mechanism as resume:
`rhel_ha_nodes[].state`, `<stage>_done` flags, cluster-scope values from the failure mail).

## Test role by role (suggested order)

1. `tests/run_tests.sh` - no infrastructure needed.
2. `--tags validate` - preflight only.
3. `--tags allocate` - roles 04/05/08/09 then 03/06/07 per node. **Spike 1 here**: confirm the standalone roles are
   happy running on `<node>-build` hosts (they may rely on `localhost` facts).
4. `--tags provision` - VMs created powered off, then `38_vmware_ha_infra` (DRS rule, shared disk). Check the VMDK is
   multi-writer on both VMs in vCenter before going on.
5. `--tags configure` - power-on, IP, IdM, Satellite, agents. Real nodes are registered at the end.
6. `--tags ha_core` - preflight (node), storage, cluster, fencing, quorum, resources, validation.
7. Disruptive tests: `-e ha_run_disruptive_tests=true -e ha_maintenance_confirmed=true` (OpsRamp maintenance first).

## Guards you should know about

- `ha_lab_mode=true` is the only way to run without fencing or with `ssl_verify=false`; it is refused unless
  `environmenttype` is set and not in `ha_prod_environment_types`.
- Shared storage requires real fencing. The shared disk must never be in `additionaldrives` (role 12 would make a private copy per node).
- Role 35 refuses a mounted device or a foreign signature unless `ha_storage_force_wipe=true`.
- Two-node quorum only (`two_node` + `wait_for_all`); `ha_quorum.qdevice` is refused.
- Secrets: vCenter and fence credentials come from AAP credential injectors (`VMWARE_*_1/_2`, `VMWARE_FENCE_USER/_PASSWORD`);
  the fence password reaches the node through a root-only script, not the CIB. SSH uses the Machine credential. No password is stored in host vars.

## Applying the patches

`patches/95_cloudstudio_update` and `patches/97_email_success` are full replacement `tasks/main.yml` files; the `.diff`
files show exactly what changed against the originals in `docs/`. Standalone behaviour is unchanged when the new
variables (`cs_resources`, `cs_no_log`, `mail_extra_html`, `mail_banner_*`, `mail_ignore_errors`) are not set.
97 keeps its CRLF line endings. Beyond the new inputs: 95 now sets `cloudstudio_onboarding` for any 2xx (it accepted
201/202 but only flagged 200), and the duplicated `lookup('env', ...) | default(lookup('env', ...))` is simplified.

## Known unknowns / follow-ups

- Role 03 pair naming: explicit node names are required (derive-mode not implemented).
- Role 07 may or may not reserve an IP without a VM; until its code is seen, the VIP is supplied (`ha_vip_reserve_mode: provided`).
- Roles 05, 06_datastore, 07, 07_second, 08, 09, 11, 12, 13, 14, 15, 28, 29, 30, 98, 99 were not seen; their guards are copied from `site.yml`.
- vSphere HA VM override has no module: manual step, reported by role 38.
- `vmware_cluster_info` is deprecated in community.vmware 6.x; the DRS check is the only user (`ha_check_drs: false` skips it).
- `argument_specs.yml` for the new roles is a worthwhile next step.
