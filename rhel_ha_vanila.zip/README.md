# RHEL 8 HA (Vanilla) - Ansible automation

Two-node Pacemaker/Corosync cluster, built by reusing the standalone RHEL roles (`aap.shared.*`) plus new HA roles,
orchestrated by `main.yml`. Backend: hand-rolled `pcs` (the RHEL system role is reserved, not built).

## Status: what has and has not been run

| Verified here (localhost, `tests/run_tests.sh`, 26 checks) | NOT verified (needs your lab) |
|---|---|
| `ansible-playbook --syntax-check`, `ansible-lint`, `yamllint` clean | Anything touching vCenter, ESXi, a real node or pcs |
| Stage runner: success, resume flag, failure -> `failmsg`/`failmail`/`sucmail`, skip-after-failure, HTML escaping | Per-node virtual build hosts with the real standalone roles (spike 1) |
| Gate: failed node promoted; node that never reached the phase marker caught | `crm_mon` XML attribute names, `pcs status nodes` output format on your RHEL minor |
| Controller preflight: example, derived names and bluecat VIP accepted; 17 bad inputs rejected; inventory (index hosts, resolve, duplicates) | `fence_vmware_rest` option names (detected via `pcs stonith describe`, still check) |
| Patched role 97 renders the cluster block for two nodes | `vmware_guest_disk` multi-writer params on your community.vmware version |

## Layout

| Path | What |
|---|---|
| `main.yml` | Plays 0-5: validate, name (serial), allocate (cluster, node serial, VIP serial), provision, configure, backup (serial), onboard, HA core, close. Tags per phase |
| `roles/ha_stage` | Stage runner (block/rescue -> framework failure convention), `gate.yml`, `close_facts.yml` |
| `roles/ha_inventory` | Virtual hosts `ha-node{N}-build` (+ `ha-vip-build`), per-node init, `resolve` (builds `ha_nodes`), real node registration (group `ha_real_nodes`) |
| `roles/39_rhel_node_build` | Wrapper: reuses standalone roles by phase (`node_name`, `cluster_allocate`, `node_allocate`, `vip_allocate`, `node_provision`, `node_configure`, `node_backup`, `node_onboard`), generated from the real `site.yml` guards |
| `roles/ha_vip_reserve` | Produces `ha_vip_resolved`; `provided` (address given) or `bluecat_07` (role 07 reserves it on `ha-vip-build`) |
| `roles/31..37` | preflight, cluster, resources, validation, shared storage, fencing, quorum |
| `roles/38_vmware_ha_infra` | DRS anti-affinity rule, shared multi-writer disk, vSphere HA reminder |
| `roles/ha_name_derive`, `ha_cloudstudio_update`, `ha_email_success` | NEW roles. The last two are copies of 95/97 with extras (diffs against the originals: `docs/diffs/`). **No existing shared role is modified.** |
| `vars/ha_example.yml` | Lab example, placeholders only |

`ha_role_ns` (in `vars/ha_common.yml`) is the namespace for the new roles (`""` = local `roles/`); switch to your
collection prefix once they move into `aap.shared`. `ha_standalone_ns` is `aap.shared.` for the existing roles.

## Run it

```bash
export ANSIBLE_CONFIG=$PWD/ansible.cfg
tests/run_tests.sh                                   # local checks first

# full run
ansible-playbook -i localhost, main.yml -e @vars/ha_example.yml

# one phase (init/gate/close plays always run; mail/CloudStudio off while testing)
ansible-playbook -i localhost, main.yml -e @vars/ha_example.yml \
  -e ha_skip_mail=true -e ha_skip_cloudstudio=true --tags allocate
```

Skipped phases only work if their results are supplied as extra_vars (same mechanism as resume:
`rhel_ha_nodes[].state`, `<stage>_done` flags, cluster-scope values from the failure mail).

## Test role by role (suggested order)

1. `tests/run_tests.sh` - no infrastructure needed.
2. `--tags validate` - preflight only.
3. `--tags allocate` - roles 04/05/08/09 then 03/06/07 per node. **Spike 1 here**: confirm the standalone roles are
   happy running on `<node>-build` hosts (they may rely on `localhost` facts).
4. `--tags provision` - VMs created powered off, then `38_vmware_ha_infra` (DRS rule, shared disk). Check the VMDK is
   multi-writer on both VMs in vCenter before going on.
5. `--tags configure` - power-on, IP, IdM, Satellite, agents. Real nodes are registered at the end.
6. `--tags ha_core` - preflight (node), storage, cluster, fencing, quorum, resources, validation.
7. Disruptive tests: `-e ha_run_disruptive_tests=true -e ha_maintenance_confirmed=true` (OpsRamp maintenance first).

## Guards you should know about

- `ha_lab_mode=true` is the only way to run without fencing or with `ssl_verify=false`; it is refused unless
  `environmenttype` is set and not in `ha_prod_environment_types`.
- Shared storage requires real fencing. The shared disk must never be in `additionaldrives` (role 12 would make a private copy per node).
- Role 35 refuses a mounted device or a foreign signature unless `ha_storage_force_wipe=true`.
- Two-node quorum only (`two_node` + `wait_for_all`); `ha_quorum.qdevice` is refused.
- Secrets: vCenter and fence credentials come from AAP credential injectors (`VMWARE_*_1/_2`, `VMWARE_FENCE_USER/_PASSWORD`);
  the fence password reaches the node through a root-only script, not the CIB. SSH uses the Machine credential. No password is stored in host vars.

## New roles instead of patches

Nothing in `aap.shared` changes. 95 and 97 are copied as `ha_cloudstudio_update` / `ha_email_success`; the standalone job keeps using the
originals. Extras: `cs_resources`, `cs_no_log` (95); `mail_extra_html`, `mail_banner_*`, `mail_ignore_errors` (97). 95 treats any 2xx as success.
Node 1 is named by the untouched role 03; node 2 by `ha_name_derive`, which takes the next free number of node 1's own sequence class
(`ha_name_sequence_step` must equal role 03's `server_name_sequence_step`, 10). If a name does not follow the 501-999 convention it stops and asks for explicit names.

## Code review result (standalone site.yml + shared roles read)

- Roles reach guests through the vCenter API / REST only, never SSH, so per-node virtual build hosts are viable.
- **Serial where roles pick "next free" or read-modify-write**: role 03 (names), 06/07/07_second (IP: HTTP 409 treated as success, so
  parallel nodes could share an address), 26 (Cohesity job). These are `serial: 1` plays.
- `rhel_ha_nodes` is only the input. Every HA role reads `ha_nodes` (name, ip, index), resolved from the build hosts after
  naming/allocation, because names may be derived by role 03 and extra vars cannot be overridden by `set_fact`.
- Names: give both or neither. Derived: role 03 for node 1, `ha_name_derive` for node 2 (no change to role 03).
- `servername` as extra var is refused (it would be handed to both nodes).
- VIP: `provided` (address given) or `bluecat_07`.
- Scope lists moved after review: `vm_cpu`, `vm_ram_mb`, `dns1/2`, `gateway`, `subnetmask` are per node; role 05 outputs (`backupserverip`,
  `backupservername`, `isactive`) per cluster.
- Close play follows site.yml: 95 only when `cloudstudio_onboarding` is none and `requestid` is set; 97 / 99 / 96 / 100 as standalone.
  `ha_email_success` keeps 97's own `completed_at`/`statuslink` role vars.
- Role 38 now sets `disk.EnableUUID=TRUE` on both VMs (stable `/dev/disk/by-id`).

## Known unknowns / follow-ups

- Role 07 for a VM-less VIP (`vip_allocate`) is an assumption from reading the role; confirm in the lab.
- Cohesity vs. multi-writer/independent-persistent disks: VM-level backup may skip or fail the shared disk. `ha_run_backup=false` skips
  role 26; agree the backup approach with the backup team before enabling.
- Role 05 / 06_datastore / 11 / 12 / 15 / 18 / 20-24 / 27 / 29 internals were read for guards and outputs, not line by line.
- vSphere HA VM override and DRS per-VM "partially automated" have no module: manual step reported by role 38.
- `vmware_cluster_info` is deprecated in community.vmware 6.x; the DRS check is the only user (`ha_check_drs: false` skips it).
- `argument_specs.yml` for the new roles is a worthwhile next step.
