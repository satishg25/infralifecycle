#!/usr/bin/env bash
# Local tests, no network, no VMware, no target hosts.   Usage: tests/run_tests.sh
set -u
cd "$(dirname "$0")/.."
export ANSIBLE_CONFIG="$PWD/ansible.cfg" ANSIBLE_ROLES_PATH="$PWD/roles:$PWD/tests/roles"
pass=0; fail=0
ok()  { echo "PASS  $1"; pass=$((pass+1)); }
bad() { echo "FAIL  $1"; fail=$((fail+1)); }
run() { ansible-playbook -i localhost, "$@" >/tmp/ha_test.out 2>&1; }

run tests/test_ha_stage.yml && ok "stage runner (success, resume, failure, skip-after-failure)" || bad "stage runner"
run tests/test_gate.yml     && ok "gate (node failure, missing marker)" || bad "gate"
run tests/test_inventory.yml && ok "inventory: index hosts, derived names, resolve, duplicates" || bad "inventory"
run tests/test_name_derive.yml && ok "partner name derivation" || bad "partner name derivation"
run tests/test_97_render.yml && ok "patched 97 renders the cluster block" || bad "patched 97 render"
run tests/test_31_controller.yml -e @vars/ha_example.yml && ok "preflight accepts example vars" || bad "preflight accepts example vars"
run tests/test_31_controller.yml -e @vars/ha_example.yml -e '{"rhel_ha_nodes":[{},{}]}' && ok "preflight accepts derived names" || bad "derived names"
run tests/test_31_controller.yml -e @vars/ha_example.yml -e '{"ha_vip_reserve_mode":"bluecat_07","ha_vip":{"name":"v"}}' && ok "preflight accepts bluecat_07 VIP" || bad "bluecat VIP"

neg() { # name, json overrides
  if run tests/test_31_controller.yml -e @vars/ha_example.yml -e "$2"; then bad "preflight rejects: $1"; else ok "preflight rejects: $1"; fi
}
neg "one node"                 '{"rhel_ha_nodes":[{"name":"a"}]}'
neg "one named, one derived"   '{"rhel_ha_nodes":[{"name":"a"},{}]}'
neg "servername extra var"     '{"servername":"x"}'
neg "VIP address in bluecat mode" '{"ha_vip_reserve_mode":"bluecat_07"}'
neg "unknown VIP mode"         '{"ha_vip_reserve_mode":"magic"}'
neg "duplicate names"          '{"rhel_ha_nodes":[{"name":"a"},{"name":"a"}]}'
neg "bad node name"            '{"rhel_ha_nodes":[{"name":"a b"},{"name":"c"}]}'
neg "bad VIP address"          '{"ha_vip":{"address":"10.0.0.999","name":"x"}}'
neg "system_role backend"      '{"ha_backend":"system_role"}'
neg "no fencing outside lab"   '{"ha_lab_mode":false,"ha_fencing":{"type":"none"}}'
neg "insecure ssl outside lab" '{"ha_lab_mode":false,"ha_fencing":{"type":"fence_vmware_rest","vcenter_host":"v","ssl_verify":false}}'
neg "lab mode in prod"         '{"environmenttype":"prod"}'
neg "lab mode, env undefined"  '{"environmenttype":null}'
neg "qdevice"                  '{"ha_quorum":{"qdevice":{"host":"q"}}}'
neg "storage without fencing"  '{"ha_fencing":{"type":"none"}}'
neg "shared disk in additionaldrives" '{"additionaldrives":["/dev/disk/by-id/REPLACE_AFTER_ATTACH"]}'
neg "disruptive without confirmation" '{"ha_run_disruptive_tests":true}'

ansible-playbook -i localhost, main.yml --syntax-check -e @vars/ha_example.yml >/tmp/ha_test.out 2>&1 && ok "main.yml syntax" || bad "main.yml syntax"
echo "passed=$pass failed=$fail"; [ "$fail" -eq 0 ]
